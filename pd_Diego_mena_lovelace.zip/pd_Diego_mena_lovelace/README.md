# PD - Diego Mena Lovelace

## Description
This project implements a normalized relational model and a simple CRUD system for **Clients**.
It includes scripts to create the database `pd_Diego_mena_lovelace`, CSV files for bulk import, a Node.js + Express backend, a minimal frontend dashboard, Postman collection and README.



## Setup (local machine)
1. Install MySQL and make sure a user with privileges (e.g., root) exists.
2. Create the database and tables:
   - Import `database.sql` using your preferred MySQL client (e.g., `mysql -u root -p < database.sql`).
3. Bulk load CSVs into the corresponding tables (examples in the `csvs` folder).
4. Backend:
   - Go to `backend/`
   - Run `npm install`
   - Run `npm start`

5. Frontend:
   - Serve the `frontend` folder (or open `frontend/index.html` in the browser). The frontend uses the API at `http://localhost:3000` by default.

