const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const pool = require('./db');
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Create client
app.post('/clients', async (req, res) => {
  try {
    const { identification, name, address, phone, email } = req.body;
    if (!name) return res.status(400).json({ error: 'name is required' });
    const [result] = await pool.query('INSERT INTO clients (identification,name,address,phone,email) VALUES (?,?,?,?,?)', [identification,name,address,phone,email]);
    const [rows] = await pool.query('SELECT * FROM clients WHERE client_id = ?', [result.insertId]);
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'internal server error' });
  }
});

// Read all clients
app.get('/clients', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM clients');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'internal server error' });
  }
});

